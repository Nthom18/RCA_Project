#include "qTable.h"


qTable::qTable(roadmap rm)
{
	indexChange = pow(2, rm.getRoadmapSize() - 1);  //"Add" one to make zero index, cancels out original one subracted

	for (int i = 0; i < rm.getRoadmapSize(); i++)
	{
		std::map<int, float> posActions;
		std::vector <int> neighbours = rm.getNodeNeighbours(i);
		for (int n : rm.getNodeNeighbours(i))
		{
			posActions.emplace(n, 0);
		}
		std::vector<std::map<int, float>> subStates(pow(2, rm.getRoadmapSize() - 1), posActions);
		Qvalues.push_back(subStates);
	}
}

int qTable::getQ(int S, int A, std::vector<bool> visitedNodes)
{
	int index = getIndex(S, visitedNodes);

	return Qvalues[S][index].at(A);
}


void qTable::setQ(int S, int A, std::vector<bool> visitedNodes, float reward)
{
	int index = getIndex(S, visitedNodes);
	Qvalues[S][index].at(A) = reward;
}

int qTable::getIndex(int S, std::vector<bool> visitedNodes)
{
	//Calculate index
	int index = 1;
	int counter = 0;
	for (bool v : visitedNodes)
	{
		//Don't count current node
		if (counter == S)
		{
		}
		//Right child
		else if (v == true)
		{
			index = index * 2 + 1;
		}
		//Left child
		else
		{
			index = index * 2;
		}
		counter++;
	}
	//Adjust index
	index = index - indexChange;

	return index;
}

void qTable::QLearning(int iterations, int steps, roadmap rm, float greedy, float alpha, float gamma)
{

	//Not random start location
	int startNode = 0;

	for (int i = 0; i < iterations; i++)
	{
		//initialize S
		int N = startNode;
		bool terminated = 0;
		std::vector<int> posActions;
		int action;
		int stepsTaken = 0;

		std::vector <bool> visitedNodes(rm.getRoadmapSize(), false);

		rm.addRandomMarblesConstTotal(100, 0);
		//rm.addRandomMarbles(rm.getRoadmapSize());

		//Loop for agent to act in
		while (!terminated) {
			//Update visitedNodes
			visitedNodes.at(N) = true;

			//test
			//std::cout << "Got here" << std::endl;
			//end test

			//Generate random number from 0 to 99 to determine if agent explores or exploits
			action = rand() % 100;

			//Next Action
			int A = -1;
			float val_a = 0;
			std::vector<int> equallyGood;

			//Exploit
			if (action >= greedy * 100)
			{
				//Get possible actions for current state
				posActions = rm.getNodeNeighbours(N);

				for (int p_a : posActions)
				{
					if (getQ(N, p_a, visitedNodes) > val_a)
					{
						A = p_a;
						val_a = getQ(N, p_a, visitedNodes);

						//New higher value found, clear any values equally good to previously belived best choice
						equallyGood.clear();

					}
					else if ((getQ(N, p_a, visitedNodes) == val_a) && (val_a > 0))
					{
						equallyGood.push_back(p_a);
					}
				}
				//If more than one action has the best estimated outcome, choose one at random
				if (equallyGood.size() > 0)
				{
					//Choose action randomly between best choices
					action = rand() % (equallyGood.size() + 1);

					if (action < equallyGood.size())
					{
						A = equallyGood[action];
					}
					//Else A keeps original value assigned to it
				}

				//If no choice made, meaning no action was better than 0, make random choice
				if (A == -1)
				{
					//If no action is better - choose action at random, from possible actions
					action = rand() % posActions.size();
					A = posActions[action];
				}

			}
			//Explorative action - choose one of all possible actions at random
			else
			{
				posActions = rm.getNodeNeighbours(N);
				action = rand() % posActions.size();
				A = posActions[action];
			}

			//Observe R
			int R = rm.getNodeReward(A);

			//Remove possible marble from node
			rm.addNodeReward(A, 0);

			//Determine the best possible action from R' (A)
			posActions = rm.getNodeNeighbours(A);
			float Q_S_markA = 0;
			for (int n : posActions)
			{
				if (getQ(A, n, visitedNodes) > Q_S_markA)
				{
					Q_S_markA = getQ(A, n, visitedNodes);
				}
			}
			//Update Q-value in Q-table
			float reward = getQ(N, A, visitedNodes) + alpha * (R + gamma * Q_S_markA - getQ(N, A, visitedNodes));
			setQ(N, A, visitedNodes, reward);

			N = A;

			stepsTaken++;
			if (stepsTaken >= steps)
			{
				terminated = 1;
			}
		}
	}
}


float qTable::bestPath(int iterations, int steps, roadmap rm)
{
	//Not random start location
	int startNode = 0;

	long int totalMarblesFound = 0;

	for (int i = 0; i < iterations; i++)
	{
		//initialize N - current Node
		int N = startNode;
		bool terminated = 0;
		std::vector<int> posActions;
		int action;
		int stepsTaken = 0;

		std::vector <bool> visitedNodes(rm.getRoadmapSize(), false);

		rm.addRandomMarblesConstTotal(100, 0);

		//Loop for agent to act in
		while (!terminated) {
			//Update visitedNodes
			visitedNodes.at(N) = true;

			//Next Action
			int A = -1;
			float val_a = 0;
			std::vector<int> equallyGood;

			//Get possible actions for current state
			posActions = rm.getNodeNeighbours(N);

			for (int p_a : posActions)
			{
				if (getQ(N, p_a, visitedNodes) > val_a)
				{
					A = p_a;
					val_a = getQ(N, p_a, visitedNodes);

					//New higher value found, clear any values equally good to previously belived best choice
					equallyGood.clear();

				}
				else if ((getQ(N, p_a, visitedNodes) == val_a) && (val_a > 0))
				{
					equallyGood.push_back(p_a);
				}
			}
			//If more than one action has the best estimated outcome, choose one at random
			if (equallyGood.size() > 0)
			{
				//Choose action randomly between best choices
				action = rand() % (equallyGood.size() + 1);

				if (action < equallyGood.size())
				{
					A = equallyGood[action];
				}
				//Else A keeps original value assigned to it
			}
			//If no choice made, meaning no action was better than 0, make random choice
			if (A == -1)
			{
				//If no action is better - choose action at random, from possible actions
				action = rand() % posActions.size();
				A = posActions[action];
			}

			//Observe R
			int R = rm.getNodeReward(A);

			//Add marble to total marbles found
			totalMarblesFound += R;

			//Remove possible marble from node
			rm.addNodeReward(A, 0);

			//Set new state
			N = A;

			stepsTaken++;
			if (stepsTaken >= steps)
			{
				terminated = 1;
			}
		}
	}

	return (float) totalMarblesFound / (float) iterations;
}
