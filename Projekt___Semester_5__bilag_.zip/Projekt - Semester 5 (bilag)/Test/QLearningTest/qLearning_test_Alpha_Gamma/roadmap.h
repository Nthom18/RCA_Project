#pragma once
#include <iostream>
#include "node.h"
class roadmap
{
public:
	roadmap(int roadmapSize, std::vector<std::pair<int, int>> vertices);

	void addNodeReward(int node, int reward);

	int getNodeReward(int node);

	std::vector<int> getNodeNeighbours(int node);

	int getRoadmapSize();

	void setAllRewards(int R);

	void addRandomMarbles(int rm_size);

	void addRandomMarblesConstTotal(int totalMarbleValue, int startPos);

private: 
	std::vector<node> nodes_m;
	int roadmapSize_m;
};
