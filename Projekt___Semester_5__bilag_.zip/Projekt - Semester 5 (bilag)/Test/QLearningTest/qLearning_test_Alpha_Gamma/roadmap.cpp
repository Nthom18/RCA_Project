#include "roadmap.h"


roadmap::roadmap(int roadmapSize, std::vector<std::pair<int, int>> vertices)
{
	node defaultNode = node();

	roadmapSize_m = roadmapSize;

	nodes_m.resize(roadmapSize, defaultNode);

	for (std::pair<int, int> v : vertices)
	{
		//Check that both corners are within the roadmap
		if ((v.first < roadmapSize) && (v.second < roadmapSize))
		{
			//Add the opposit nodes as neighbour to the nodes
			nodes_m[v.first].addNeighbour(v.second);
			nodes_m[v.second].addNeighbour(v.first);
		}
	}
}

void roadmap::addNodeReward(int node, int reward)
{
	nodes_m[node].setReward(reward);
}

int roadmap::getNodeReward(int node)
{
	return nodes_m[node].getReward();
}

std::vector<int> roadmap::getNodeNeighbours(int node)
{
	return nodes_m[node].getNeighbours();
}

int roadmap::getRoadmapSize()
{
	return roadmapSize_m;
}

void roadmap::setAllRewards(int R)
{
	for (node n : nodes_m)
	{
		n.setReward(R);
	}
}

void roadmap::addRandomMarbles(int rm_size) {
	//Random marble generation 
	int numberOfMarbles = 1 + rand() / (rm_size / 2);//1 + rand() % 9;
	std::vector<int> alreadyAssigned;
	int pos;
	int i = 0;

	//Make sure no marbles are left from last run
	setAllRewards(0);

	while (i < numberOfMarbles)
	{
	//Generate random position
	generateMarble:
		pos = rand() % rm_size;
		for (int a : alreadyAssigned)
		{
			if (pos == a)
			{
				goto generateMarble;
			}
		}

		//Set reward at node
		if ((pos == 0) || (pos == 8) || (pos == 10) || (pos == 14) || (pos == 17) || (pos == 20))
		{
			addNodeReward(pos, 15);
		}
		else if ((pos == 2) || (pos == 12) || (pos == 15) || (pos == 16))
		{
			addNodeReward(pos, 5);
		}
		else
		{
			addNodeReward(pos, 10);
		}

		alreadyAssigned.push_back(pos);
		i++;
	}
}

void roadmap::addRandomMarblesConstTotal(int totalMarbleValue, int startPos) {
	//Random marble generation 
	int curMarbleValues = 0;

	std::vector<int> alreadyAssigned;
	int alreadyAssignedNr = 1;
	int pos;
	int i = 0;

	//Make sure no marbles are left from last run
	setAllRewards(0);

	while (curMarbleValues < totalMarbleValue)
	{
	//Generate random position
	generateMarble:
		if (alreadyAssignedNr > roadmapSize_m-1)
		{
			std::cout << "ERROR! All nodes assigned value! " << std::endl;
			return;
		}
		pos = rand() % roadmapSize_m;
		for (int a : alreadyAssigned)
		{
			if (pos == a || pos == startPos)
			{
				goto generateMarble;
			}
		}
		alreadyAssignedNr++;
		

		//Set reward at node
		if ((pos == 0) || (pos == 8) || (pos == 10) || (pos == 14) || (pos == 17) || (pos == 20))
		{
			if ((curMarbleValues + 15) <= totalMarbleValue)
			{
				addNodeReward(pos, 15);
				curMarbleValues += 15;
			}
			else 
			{
				addNodeReward(pos, totalMarbleValue - curMarbleValues);
				curMarbleValues += totalMarbleValue - curMarbleValues;
			}
		}
		else if ((pos == 2) || (pos == 12) || (pos == 15) || (pos == 16))
		{
			addNodeReward(pos, 5);
			curMarbleValues += 5;
		}
		else
		{
			if ((curMarbleValues + 10) <= totalMarbleValue)
			{
				addNodeReward(pos, 10);
				curMarbleValues += 10;
			}
			else
			{
				addNodeReward(pos, totalMarbleValue - curMarbleValues);
				curMarbleValues += totalMarbleValue - curMarbleValues;
			}
		}
		alreadyAssigned.push_back(pos);
	}
}