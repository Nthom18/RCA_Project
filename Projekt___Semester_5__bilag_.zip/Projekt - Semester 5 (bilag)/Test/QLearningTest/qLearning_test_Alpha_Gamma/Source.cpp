#include <istream>
#include "roadmap.h"
#include "node.h"
#include "qTable.h"
#include <ctime>
#include <map>
#include <fstream>

//Epsilon
#define epsilon  0.1

//Number of steps
#define STEPS	10

//Number of iterations
#define ITERATIONS 1000

//Number of tests
#define NRTESTS	1000


int main()
{
	//Create roadmap
	roadmap rm_one = roadmap(17, { {0, 1}, {1, 2}, {2, 3}, {2, 4}, {4, 5}, {4, 6}, {6, 7},{2, 6},{6, 8}, {2, 9} ,{9, 10},{10, 11} ,{11, 12},{9, 12} ,{12, 13} ,{13, 14} , {13, 15}, {15, 16}});

	srand(std::time(nullptr));

	int iterations = 1000;
	int qTables = 10;

	//Test one
	std::ofstream testdataone("testOneDataAlphaGamma.csv");

	for (float alpha = 0.2; alpha < 1; alpha = alpha + 0.2)
	{
		for (float gamma = 0.2; gamma < 1; gamma = gamma + 0.2)
		{
			float total = 0;
			for (int test = 0; test < qTables; test++)
			{
				qTable qt_one = qTable(rm_one);

				qt_one.QLearning(iterations, STEPS, rm_one, epsilon, alpha, gamma);
				float average = qt_one.bestPath(NRTESTS, STEPS, rm_one);


				total += average;
			}
			testdataone << alpha << ", " << gamma << ", " << total / qTables << '\n';
			std::cout << "Test performed! " << alpha << ", " << gamma << ", " << total / qTables << '\n';

		}
	}

	testdataone.close();

	//Test two
	//float bestAlpha = 0.2; //INSERT BEST ALPHA FROM TEST ONE;
	//float bestGamma = 0.8; //INSERT BEST GAMMA FROM TEST ONE;

	//std::ofstream testdatatwo("testTwoDataAlphaGamma.csv");

	//for (float alpha = bestAlpha - 0.15 ; alpha <= bestAlpha + 0.15; alpha = alpha + 0.05 )
	//{
	//	for (float gamma = bestGamma - 0.15; gamma <= bestGamma + 0.15; gamma = gamma + 0.05)
	//	{
	//		float total = 0;
	//		for(int test = 0; test < qTables; test++)
	//		{
	//			qTable qt_one = qTable(rm_one);

	//			qt_one.QLearning(iterations, STEPS, rm_one, epsilon, alpha, gamma);
	//			float average = qt_one.bestPath(NRTESTS, STEPS, rm_one);

	//			
	//			total += average;
	//		}
	//		testdatatwo << alpha << ", " << gamma << ", " << total / qTables << '\n';
	//		std::cout << "Test performed! " << alpha << ", " << gamma << ", " << total / qTables << '\n';

	//	}
	//}
	//testdatatwo.close();

	return 1;
}