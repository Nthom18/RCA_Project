#pragma once
#include <vector>
class node
{
public:
	node()
	{
		reward_m = 0;
	}

	node(std::vector<int> n_neighbours)
	{
		neighbours_m = n_neighbours;
		reward_m = 0;
	}

	void setReward(int reward)
	{
		reward_m = reward; 
	}

	int getReward()
	{
		return reward_m;
	}


	void addNeighbour(int n)
	{
		neighbours_m.push_back(n);
	}

	std::vector<int> getNeighbours()
	{
		return neighbours_m;
	}

private:
	int reward_m;
	std::vector<int> neighbours_m;
};

