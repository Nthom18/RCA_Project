#pragma once
#include <vector>
#include <map>
#include "roadmap.h"
#include <vector>

class qTable
{
public:
	qTable(roadmap rm);


	int getQ(int S, int A, std::vector<bool> visitedNodes);
	
	void setQ(int S, int A, std::vector<bool> visitedNodes, float reward);

	int getIndex(int S, std::vector<bool> visitedNodes);

	void QLearning(int iterations, int steps, roadmap rm, float greedy, float alpha, float gamma);

	float bestPath(int iterations, int steps, roadmap rm);

private:
	std::vector<std::vector<std::map<int, float>>> Qvalues;
	int indexChange; 
};

