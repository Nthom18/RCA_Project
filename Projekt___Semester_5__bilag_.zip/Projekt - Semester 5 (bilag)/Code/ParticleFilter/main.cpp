#include <iostream>
#include <fstream>
#include <string>
#include<windows.h>

#include "ParticleFilter.h"


int main()
{
	cv::Mat image = cv::imread("floor_plan.png");
	cv::Mat resize_image;
	cv::resize(image, resize_image, cv::Size(), 7, 7, cv::INTER_NEAREST);

	std::ifstream Gazebo("memory.txt");

	ParticleFilter filter(resize_image);

	int iteration = 0;
	while (true)
	{
		iteration++;

		std::string s_speed, s_dir, s_centerLidar, s_xPos, s_yPos;
		Gazebo >> s_speed;
		Gazebo >> s_dir;
		Gazebo >> s_centerLidar;
		Gazebo >> s_xPos;
		Gazebo >> s_yPos;

		float speed, dir, centerLidar, xPos, yPos;
		speed = std::stof(s_speed);
		dir = std::stof(s_dir);
		centerLidar = std::stof(s_centerLidar);
		xPos = std::stof(s_xPos);
		yPos = std::stof(s_yPos);

		filter.CreateParticles(centerLidar, speed, dir, xPos, yPos);
		cv::waitKey(25);
		//cv::waitKey();
		//std::cout << "iteration: " << iteration << ", Speed: " << speed << ", dir: " << s_dir << ", centerLidar: " << s_centerLidar << std::endl;


		std::string line;
		if (!getline(Gazebo, line))
		{
			break;
		}
	}

	return 0;
}
