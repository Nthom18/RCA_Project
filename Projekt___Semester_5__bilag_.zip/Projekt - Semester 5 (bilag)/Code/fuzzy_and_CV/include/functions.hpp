#pragma once

#include <iostream>

void printSomething()
{
    std::cout << "Something" << std::endl;
}