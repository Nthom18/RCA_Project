#include <iostream>
#include "priorityQueue.h"
#include <vector>
#include <ctime>

//Test one
#define startValue		1000
#define incrementTest	100
#define lastTest		10000

////Test two
//#define startValue		5000
//#define incrementTest	5000
//#define lastTest		30000


//Function for generation of vector with random numbers
std::vector<int> random_vector(int size);

int main() 
{ 
	int kth_element; 
	srand(std::time(nullptr));
	int randomKth;
	int N;
	
	//N = 1000;

	std::vector<int> randomVector;
	float counterForC = 0;


	for(int N = startValue; N <= lastTest; N=N+incrementTest)
	{
		counterForC = 0;

		for (int i = 0; i < 100; i++)
		{
			randomVector.clear();
			randomVector = random_vector(N);

			priorityQueue queue1 = priorityQueue(randomVector);
			queue1 = priorityQueue(randomVector);

			randomKth = (rand() % (N - 1)) + 1;

			kth_element = queue1.kthElement(randomKth);

			counterForC += queue1.counter;
			queue1.clear();
		}

		std::cout << N << " " << counterForC/100 << ";";
		
	}
	return 1;
}

std::vector<int> random_vector(int size)
{
	std::vector<int> numbers;

	int randomNumber;
	for (int i = 0; i < size; i++)
	{
	here:
		randomNumber = rand() % 100000;
		for (int n : numbers)
		{
			if (randomNumber == n)
			{
				goto here;
			}
		}
		numbers.push_back(randomNumber);
	}
	return numbers;
}