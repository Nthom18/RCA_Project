#include <istream>
#include "roadmap.h"
#include "node.h"
#include "qTable.h"
#include <ctime>
#include <map>

//Discount factor
#define gamma 0.85

//Learning rate
#define alpha	0.25

//Ebsilon
#define epsilon  0.1

//Number of steps
#define STEPS	10

//Number of iterations
#define ITERATIONS 1000

//Number of tests
#define NRTESTS	1000


int main()
{
	//Create roadmap
	roadmap rm_one = roadmap(17, { {0, 1}, {1, 2}, {2, 3}, {2, 4}, {4, 5}, {4, 6}, {6, 7},{2, 6},{6, 8}, {2, 9} ,{9, 10},{10, 11} ,{11, 12},{9, 12} ,{12, 13} ,{13, 14} , {13, 15}, {15, 16} });

	srand(std::time(nullptr));

	//Create q-table
	qTable qt_one = qTable(rm_one);

	//Vector of visited nodes
	std::vector <bool> visitedNodes(rm_one.getRoadmapSize(), false);

	qt_one.QLearning(ITERATIONS, STEPS, rm_one, epsilon, alpha, gamma);
	float average = qt_one.bestPath(NRTESTS, STEPS, rm_one);

	std::cout << "Average marbles collected: " << average << std::endl;



	return 1;
}