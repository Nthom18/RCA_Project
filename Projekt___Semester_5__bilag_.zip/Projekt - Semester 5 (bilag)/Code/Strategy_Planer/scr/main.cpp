#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/imgcodecs/imgcodecs.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc.hpp>

#include <vector>
#include "../include/Roadmap.hpp"
#include <random>

int main()
{
    //cv::Mat image = cv::imread("../foor_v2.png");
    cv::Mat image = cv::imread("../floor_plan.png");
    cv::Mat out_image;
    cv::resize(image, out_image, cv::Size(), 7, 7, cv::INTER_NEAREST);

    Roadmap map(out_image);

//    cv::Mat newTest;
//    cv::resize(test, newTest, cv::Size(), 4, 4);


    cv::Point start(480,180);
    cv::Point stop(600,400);
    map.PathOrder(start);

    //map.Pathfinding(start, stop);

    cv::imshow("image", out_image);
    cv::waitKey();
    
    return 0;
}