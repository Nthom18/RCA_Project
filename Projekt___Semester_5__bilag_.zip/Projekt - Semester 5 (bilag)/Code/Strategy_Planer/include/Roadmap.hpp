#ifndef ROADMAP_HPP
#define ROADMAP_HPP

#include <iostream>
#include <opencv2/core/core.hpp>
#include <opencv2/imgcodecs/imgcodecs.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc.hpp>

//#include "Node.hpp"

#include <vector>
#include <random>
#include <algorithm>
#include <cmath>
#include <thread>

struct Node
{
    cv::Point position;
    std::vector<Node> neighbours;
    bool connected = false;

};

class Roadmap
{
public:
    Roadmap()
    {

    };

    Roadmap(cv::Mat _image)
    {
        image = _image;

        // Find corners
        std::vector<cv::Point> points;
        std::vector<cv::Point> corners;
        for(int i = 0; i < image.cols; i++)
        {
            for(int j = 0; j < image.rows; j++)
            {
                if(!(i == 0 || i == image.cols || j == 0 || j == image.rows))  // Ensure in bounce check
                {
                    cv::Vec3b currentPixelColor = image.at<cv::Vec3b>(cv::Point(i,j)); // Only check black pixels
                    if(currentPixelColor.val[0] == 0 && currentPixelColor.val[1] == 0 && currentPixelColor.val[2] == 0)
                    {
                        if(CheckArea(cv::Point(i,j), image))    // Find areas that furfill requirements
                        {
                            corners.push_back(cv::Point(i,j));
                            points.push_back(cv::Point(i,j));
                        }
                    }
                }
            }
        }

        // Check vertically if any objects are pressent
        cv::Vec3b blue = cv::Vec3b(255, 0, 0);
        for(cv::Point &currentCorner : corners)
        {
            // Check upwards
            for(int i = currentCorner.y - 1 ; i > 0 ; i--)
            {
                cv::Vec3b currentPixelColor = image.at<cv::Vec3b>(cv::Point(currentCorner.x, i));
                if(currentPixelColor.val[0] == 0 && currentPixelColor.val[1] == 0 && currentPixelColor.val[2] == 0)
                {
                    points.push_back(cv::Point(currentCorner.x, i));
                    break;
                }
                else if(i == 1)
                {
                    points.push_back(cv::Point(currentCorner.x, i - 1));
                    break;
                }
                else
                {
                    // Debug, visualise line
                    //image.at<cv::Vec3b>(cv::Point(currentCorner.x, i)) = cv::Vec3b(255, 0, 0);
                }
            }

            // Check downwards
            for(int j = currentCorner.y + 1 ; j < image.rows ; j++)
            {
                cv::Vec3b currentPixelColor = image.at<cv::Vec3b>(cv::Point(currentCorner.x, j));
                if(currentPixelColor.val[0] == 0 && currentPixelColor.val[1] == 0 && currentPixelColor.val[2] == 0)
                {
                    points.push_back(cv::Point(currentCorner.x, j));
                    break;
                }
                else if(j == image.rows - 1)
                {
                    points.push_back(cv::Point(currentCorner.x, j + 1));
                    break;
                }
                else
                {
                    // Debug, visualise lines
                    //image.at<cv::Vec3b>(cv::Point(currentCorner.x, j)) = cv::Vec3b(255,0,0);
                }
            }
        }

        // Add all points to placement Matrix, and show corners if needed
        for(cv::Point dummy : points)
        {
            PlacePointInMatrix(dummy);
            //std::cout << dummy.x << " " << dummy.y << std::endl; 
            //cv::circle(image, dummy, 4, cv::Scalar(0,255,0), 2, cv::LINE_8);
        }

        // Go though all points, and find rectangles
        std::vector<std::vector<cv::Point>> copyMatrix = matrix;
        std::vector<cv::Point> newPoints;
        for(int i = 0; i < matrix.size() - 1; i++)
        {
            for(int j = 0; j < matrix[i].size() - 1; j++)
            {   
                // Find point underneath
                bool found = false;
                for(int p = 0; p < copyMatrix.size(); p++)
                {
                    if(found)
                        break;

                    if(matrix[i][j].y < copyMatrix[p][0].y - 1)     // Check if y is less
                    {
                        for(int q = 0; q < copyMatrix[p].size(); q++)
                        {
                            if(matrix[i][j].x == copyMatrix[p][q].x)    // Check if the y has a matching x
                            {
                                if(matrix[i][j + 1].x == copyMatrix[p][q + 1].x && matrix[i][j].x != matrix[i][j+1].x) // Check if point furfill requirements
                                {
                                    cv::Point currentPos;
                                    bool collision = false;
                                    for(float t = 0.04 ; t < 1 - 0.04 ; t += 0.01)             // Create Bezier line
                                    {
                                        currentPos = (1-t)*matrix[i][j] + t*copyMatrix[p][q+1];

                                        // Check if area is black
                                        cv::Vec3b tempColor = image.at<cv::Vec3b>(currentPos);
                                        if((int)tempColor.val[0] == 0 && (int)tempColor.val[1] == 0 && (int)tempColor.val[2] == 0)
                                        {
                                            collision = true;
                                        }
                                    }   
                                    
                                    if(collision)
                                    {
                                        break;
                                    }
                                    
                                    // THESE ARE THE ACTUAL SQUARE POINTS!
                                    cv::Point outputPoint = cv::Point((matrix[i][j].x + copyMatrix[p][q+1].x)/2, (matrix[i][j].y + copyMatrix[p][q+1].y)/2);
                                    //cv::line(image, matrix[i][j], copyMatrix[p][q+1], cv::Scalar(0, 255, 255), 1, cv::LINE_8);

                                        // Check for dublicates 
                                        //----------------------------------
                                        bool checkDub = false;
                                        for(cv::Point testPoint : path)
                                        {
                                            if(testPoint == outputPoint)
                                            {
                                                checkDub = true;
                                            }
                                        }

                                        if(checkDub)
                                        {
                                            break;
                                        }
                                        //----------------------------------

                                    //cv::circle(image, cv::Point((matrix[i][j].x + copyMatrix[p][q+1].x)/2, (matrix[i][j].y + copyMatrix[p][q+1].y)/2), 3, cv::Scalar(100,100,0), 1, cv::LINE_8);
                                    path.push_back(outputPoint);
                                    newPoints.push_back(cv::Point((matrix[i][j].x + copyMatrix[p][q+1].x)/2, (matrix[i][j].y + copyMatrix[p][q+1].y)/2));
                                    found = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        std::vector<cv::Point> pathCopy = path;
        std::vector<cv::Point> pathCopy2 = pathCopy;
        int maxDistance = 25;
        for(cv::Point lookAt : path)
        {
            for(int j = 0; j < pathCopy.size(); j++)
            {
                if(!(lookAt == pathCopy[j]))
                {
                    if(CalcDistance(lookAt, pathCopy[j]) < maxDistance)
                    {
                        RemoveValue(pathCopy[j], path);
                    }
                }
            }
        }

        
        for(cv::Point dummy : path)
        {
            cv::circle(image, dummy, 3, cv::Scalar(100,100,0), 1, cv::LINE_8);
        }
        

    }

    void PathOrder(cv::Point start)
    {
        // Make start a Node
        cv::circle(image, start, 3, cv::Scalar(0,0,255), 1, cv::LINE_8);

        std::vector<cv::Point> closedPoints;
        std::vector<cv::Point> openPoints = path;

        int index = 0;
        cv::putText(image, std::to_string(index), start, cv::FONT_HERSHEY_COMPLEX_SMALL, 0.5, cv::Scalar(0,0,255), 1, cv::LINE_8);
        index++;

        cv::Point currentPoint = start;
        while(openPoints.size() > 0)
        {
            closedPoints.push_back(currentPoint);

            // Find all reachable elements
            std::vector<cv::Point> reachable;
            for(int i = 0; i < openPoints.size(); i++)
            {
                if(!CheckCollision(currentPoint, openPoints[i], 0.01))
                {

                    reachable.push_back(openPoints[i]);
                }
            }

            if(reachable.size() != 0)   // If any points are reachable
            {  
                // Find closest reachble point
                int maxDistance = 10000;
                int arrayPos;
                for(int i = 0; i < reachable.size(); i++)  // Find closest element
                {
                    int calculatedDistance = CalcDistance(currentPoint, reachable[i]);
                    if(calculatedDistance < maxDistance)
                    {
                        maxDistance = calculatedDistance;
                        arrayPos = i;
                    }
                }

                if(maxDistance != 10000)
                {
                    cv::line(image, currentPoint, reachable[arrayPos], cv::Scalar(255, 0, 0), 1, cv::LINE_8);
                    currentPoint = reachable[arrayPos];
                    cv::putText(image, std::to_string(index), currentPoint, cv::FONT_HERSHEY_COMPLEX_SMALL, 0.8, cv::Scalar(0,0,255), 1, cv::LINE_8);
                    RemoveValue(currentPoint, openPoints);
                }
            }
            else // If no reachable points were found
            {
                // Check if a previous point can reach a new point
                bool subPoint = false;
                for(int i = closedPoints.size() - 1; 0 <= i; i--)
                {
                    std::vector<cv::Point> subReachable;    // Find all collision free points
                    for(int j = 0; j < openPoints.size(); j++)
                    {
                        if(!CheckCollision(closedPoints[i], openPoints[j], 0.01))
                        {
                            subReachable.push_back(openPoints[j]);
                            subPoint = true;
                        }
                    }
                    
                    // Find closest point
                    if(subPoint)
                    {
                        cv::Point closestSubPoint;
                        int maxDist = 10000;
                        for(int j = 0; j < subReachable.size(); j++)
                        {
                            int newDist = CalcDistance(closedPoints[i], subReachable[j]);
                            if(newDist < maxDist)
                            {
                                maxDist = newDist;
                                closestSubPoint = subReachable[j];
                            }
                        }

                        cv::line(image, closedPoints[i], closestSubPoint, cv::Scalar(255, 0, 0), 1, cv::LINE_8);
                        currentPoint = closestSubPoint;
                        cv::putText(image, std::to_string(index), closestSubPoint, cv::FONT_HERSHEY_COMPLEX_SMALL, 0.8, cv::Scalar(0,0,255), 1, cv::LINE_8);
                        RemoveValue(closestSubPoint, openPoints);
                        break;
                    }
                    
                }

                // If there were found no other posible rute, choose the closest one. 
                if(!subPoint)
                {
                    // Find closest reachble point
                    int maxDistance = 10000;
                    int arrayPos;
                    for(int i = 0; i < openPoints.size(); i++)  // Find closest element
                    {
                        int calculatedDistance = CalcDistance(currentPoint, openPoints[i]);
                        if(calculatedDistance < maxDistance)
                        {
                            maxDistance = calculatedDistance;
                            arrayPos = i;
                        }
                    }

                    if(maxDistance != 10000)
                    {
                        cv::line(image, currentPoint, openPoints[arrayPos], cv::Scalar(0, 0, 255), 1, cv::LINE_8);
                        currentPoint = openPoints[arrayPos];
                        cv::putText(image, std::to_string(index), currentPoint, cv::FONT_HERSHEY_COMPLEX_SMALL, 0.8, cv::Scalar(0,0,255), 1, cv::LINE_8);
                        RemoveValue(currentPoint, openPoints);
                        std::cout << std::endl << std::endl;
                    }
                }
            }

            index++;
        }
        order = closedPoints;
    }

    void PlacePointInMatrix(cv::Point point)
    {
        if(point.y > maxY)
        {
            maxY = point.y;
            matrix.push_back(std::vector<cv::Point>());
            matrix[matrix.size() - 1].push_back(point);

            return;
        }

        if(point.y <= maxY)
        {            
            for(int i = 0; i < matrix.size(); i++)
            {
                if(point.y == matrix[i][0].y)
                {
                    for(int j = 0; j < matrix[i].size(); j++)
                    {
                        if(point.x <= matrix[i][j].x)
                        {
                            matrix[i].insert(matrix[i].begin() + j, point);
                            return;
                        }
                    }

                    matrix[i].push_back(point);
                    return;
                }

                if(point.y < matrix[i][0].y)
                {
                    matrix.insert(matrix.begin() + i, std::vector<cv::Point>());
                    matrix[i].push_back(point);
                    return;
                }

            }
        }
    }

    void printMatrix()
    {
        for(int i = 0; i < matrix.size(); i++)
        {
            for(int j = 0; j < matrix[i].size(); j++)
            {
                std::cout << "(" << matrix[i][j].x << "," << matrix[i][j].y << ") ";
            }
            std::cout << std::endl;
        }
    }

    std::vector<std::vector<cv::Point>> matrix;

    std::vector<cv::Point> path;
    std::vector<cv::Point> order;


private:
    int maxX = -1;
    int maxY = -1;
    
    bool pathCreated = false;
    cv::Mat image;

    int CalcDistance(cv::Point p1, cv::Point p2)
    {
        return std::sqrt(std::pow(p1.x - p2.x, 2) + std::pow(p1.y - p2.y, 2));
    }

    bool CheckCollision(cv::Point start, cv::Point stop, float accuracy)
    {
        // Check the points can reach each other
        cv::Point currentPos;
        bool collision = false;
        for(float t = 0 ; t < 1 ; t += accuracy)             // Create Bezier line
        {
            currentPos = (1-t)*start + t*stop;

            // Check if area is black
            cv::Vec3b tempColor = image.at<cv::Vec3b>(currentPos);
            if((int)tempColor.val[0] == 0 && (int)tempColor.val[1] == 0 && (int)tempColor.val[2] == 0)
            {
                collision = true;
            }
        }

        return collision;
    }

    bool CheckArea(cv::Point position, cv::Mat image)
    {
        int whitePixelCount = 0;
        int blackPixelCount = 0;
        for(int i = -1 ; i < 2; i++)
        {
            for(int j = -1 ; j < 2; j++)
            {
                cv::Vec3b value = image.at<cv::Vec3b>(cv::Point(position.x + j, position.y + i));
                
                if(value.val[0] == 255 && value.val[1] == 255 && value.val[2] == 255)
                {
                    whitePixelCount++;
                }
                else
                {
                    blackPixelCount++;
                }
            }
        }

        if(whitePixelCount == 1 && blackPixelCount == 8)
        {
            return true;
        }

        
        if(blackPixelCount == 4 && whitePixelCount == 5)
        {
            return true;
        }
        
        return false;
    }

    bool FindNodeMatch(Node lookFor, int &pos, std::vector<Node> array)
    {
        for(int i = 0; i < array.size(); i++)
        {
            if(lookFor.position == array[i].position)
            {
                pos = i;
                return true;
            }
        }
        return false;
    }

    template<class T>
    void RemoveValue(T rem, std::vector<T> &array)
    {
        array.erase(std::remove(array.begin(), array.end(), rem), array.end());
    }

};

#endif