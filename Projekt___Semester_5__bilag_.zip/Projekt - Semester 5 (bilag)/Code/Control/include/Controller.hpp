#include <iostream>
#include <thread>
#include <chrono>

void Direction(int &milisec, double& dir, double degree, double timeSecond, double startSeconds)
{
    int startMiliseconds = startSeconds * 1000;
    std::chrono::steady_clock::time_point start = std::chrono::steady_clock::now();
    while(true)
    {
        if(std::chrono::steady_clock::now() - start > std::chrono::milliseconds(startMiliseconds))
        {
            break;
        }
    }
    

    int timeMiliseconds = timeSecond * 1000;
    double rad = (degree * 3.14159265358979323846)/180;
    //std::cout << "Rad: " << rad << " , " << "Rads Per Second: " << rad/timeSecond << std::endl;
    double radPerSecond = rad/timeSecond; //+ (3.14-2.187095))/timeSecond; // Convert degree to rad/s
    std::cout << "RadPerSeond : " << radPerSecond << std::endl;
    //double radPerSecond = degree/timeSecond * 0.017453;


    
    milisec = 0;
    while(milisec <= timeMiliseconds)
    {
        dir = radPerSecond;
    }
    dir = 0;
    
   /*
    start = std::chrono::steady_clock::now();
    while(true)
    {
        dir = radPerSecond;
        if(std::chrono::steady_clock::now() - start > std::chrono::milliseconds(timeMiliseconds))
        {
            dir = 0;
            break;
        }
    }
    */
}

void SpeedModify(int &miliSec, double& speed, double meters, double timeSecond, double startSeconds)
{
    int startMiliseconds = startSeconds * 1000;
    std::chrono::steady_clock::time_point start = std::chrono::steady_clock::now();
    while(true)
    {
        if(std::chrono::steady_clock::now() - start > std::chrono::milliseconds(startMiliseconds))
        {
            break;
        }
    }

    int timeMiliseconds = timeSecond * 1000;
    //double radPerSecond = ((degree * 3.14159265358979323846)/180)/timeSecond; // Convert degree to rad/s
    double metersPerSecond = meters/timeSecond;
    start = std::chrono::steady_clock::now();
    while(true)
    {
        speed = metersPerSecond;
        if(std::chrono::steady_clock::now() - start > std::chrono::milliseconds(timeMiliseconds))
        {
            speed = 0;
            break;
        }
    }
}


class Controller
{
public:

Controller()
{
    dir = 0;
    speed = 0;
    currentRotation = 0;
}

void ChangeDirection(int &miliSec, double degree, double timeSeconds, double startSeconds)
{
    std::thread DirectionTime(Direction, std::ref(miliSec), std::ref(dir), degree, timeSeconds, startSeconds);
    DirectionTime.detach();
    currentRotation += ((degree * 3.14159265358979323846)/180)/timeSeconds;
}

void ChangeSpeed(int &miliSec, double meters, double timeSeconds, double startSeconds)
{
    std::thread SpeedTime(SpeedModify, std::ref(miliSec), std::ref(speed), meters, timeSeconds, startSeconds);
    SpeedTime.detach();
}

double dir;
double speed;
double currentRotation;

};


